Simple DDD persistence sample using ORM
=======================================

By uian2000.

# Presentation

This is a simple project which shows how to define a DDD persistence factory.

It was first published on the forum to identify an issue with TSynFilterTrim (which has therefore been fixed since).

# Forum Thread

See http://synopse.info/forum/viewtopic.php?id=3183

